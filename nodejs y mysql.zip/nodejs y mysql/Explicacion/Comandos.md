-----------------------------------------------------------------------------------------------------------------------------------
## instalacion del servidor
-----------------------------------------------------------------------------------------------------------------------------------
# primero creamos el paquete de dependencias
npm init --yes
-----------------------------------------------------------------------------------------------------------------------------------
# Ahora instalamos los modulos que vamos a utilizar en el proyecto
npm install express mysql express-myconnection morgan ejs
-----------------------------------------------------------------------------------------------------------------------------------
# creamos la carpeta "src" y dentro el archivo "app.js" en el cual meteremos lo siguiente
```bash
const express = require('express') # con este comando indcamos que requeriremos de express
const app = express(); # el servidor sera ejecutado en express

app.listen(3000, () => {
    console.log('server on port 3000');
}); # el host ser:
```
-----------------------------------------------------------------------------------------------------------------------------------
# ahora iniciamos nos aparecera error (Cannot GET /) pero es un mensaje de error de express con lo cual si funciona
node src/app.js
-----------------------------------------------------------------------------------------------------------------------------------
# añadimos mas codigo a "app.js"
```bash
const express = require('express')
const path = require('path')
const morgan = require('morgan')

const app = express();

// setings
app.set('port', process.env.PORT || 3000); #
app.set('view engine', 'ejs'); #
app.set('views', path.join(__dirname, 'views')); #

// middlewares
app.use(morgan('dev')); #
app.use(myConnection(mysql, {
    host: 'localhost',
    user: 'root',
    password: '1234',
    port: 3306,
    database: 'crudnodejsmysql' #

// routes


app.listen(3000, () => {
    console.log('server on port 3000');
});
```
-----------------------------------------------------------------------------------------------------------------------------------
# seguimos iniciando "app.js" con "nodemon"
nodemon src/app.jss
-----------------------------------------------------------------------------------------------------------------------------------
# ahora creamos otra carpeta en la raiz del proyecto que se llamara "database" en la cual crearemos una base de dados de sql
# dentro colocamos el siguiente codigo
-- creating database
CREATE DATABASE crudenodejsmysql;

-- using database
use crudenodejsmysql

-- Creating a table
CREATE TABLE customer (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KAY,
    name VARCHAR(50) NOT NULL,
    address VARCHAR(100) NOT NULL,
    phone VARCHAR(15)
);

-- tp show all tables
SHOW TABLES;

-- to describe the table
describe customer;
-----------------------------------------------------------------------------------------------------------------------------------
minuto de video 24,52
